--
-- PostgreSQL database dump
--

\restrict y6znbMvkdZYccXsOOcjv0aeKzV5T9YYH3eaXWA7rXvBSdQsbsWBgo58HhWIVFTE

-- Dumped from database version 17.9
-- Dumped by pg_dump version 17.9

-- Started on 2026-04-03 14:48:38

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 16698)
-- Name: hotel_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hotel_schema;


ALTER SCHEMA hotel_schema OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 233 (class 1259 OID 16792)
-- Name: bookings; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.bookings (
    booking_id integer NOT NULL,
    room_id integer,
    employee_id integer,
    lodger_id integer,
    promo_id integer,
    check_in date,
    check_out date,
    status character varying(50)
);


ALTER TABLE hotel_schema.bookings OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 16791)
-- Name: bookings_booking_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.bookings_booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.bookings_booking_id_seq OWNER TO postgres;

--
-- TOC entry 5007 (class 0 OID 0)
-- Dependencies: 232
-- Name: bookings_booking_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.bookings_booking_id_seq OWNED BY hotel_schema.bookings.booking_id;


--
-- TOC entry 237 (class 1259 OID 16831)
-- Name: cleaning; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.cleaning (
    cleaning_id integer NOT NULL,
    room_id integer,
    employee_id integer,
    cleaning_date date,
    status character varying(20),
    CONSTRAINT cleaning_status_check CHECK (((status)::text = ANY ((ARRAY['clean'::character varying, 'not_clean'::character varying])::text[])))
);


ALTER TABLE hotel_schema.cleaning OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 16830)
-- Name: cleaning_cleaning_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.cleaning_cleaning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.cleaning_cleaning_id_seq OWNER TO postgres;

--
-- TOC entry 5008 (class 0 OID 0)
-- Dependencies: 236
-- Name: cleaning_cleaning_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.cleaning_cleaning_id_seq OWNED BY hotel_schema.cleaning.cleaning_id;


--
-- TOC entry 229 (class 1259 OID 16760)
-- Name: employees; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.employees (
    employee_id integer NOT NULL,
    hotel_id integer,
    type_of_employment character varying(50),
    contract_number character varying(50),
    date_of_conclusion date,
    end_date date,
    terms_of_the_contract text,
    job_title character varying(50),
    rates numeric(3,1)
);


ALTER TABLE hotel_schema.employees OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16759)
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.employees_employee_id_seq OWNER TO postgres;

--
-- TOC entry 5009 (class 0 OID 0)
-- Dependencies: 228
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.employees_employee_id_seq OWNED BY hotel_schema.employees.employee_id;


--
-- TOC entry 219 (class 1259 OID 16700)
-- Name: hotels; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.hotels (
    hotel_id integer NOT NULL,
    name character varying(100),
    city character varying(50),
    address text,
    phone_number character varying(50)
);


ALTER TABLE hotel_schema.hotels OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16699)
-- Name: hotels_hotel_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.hotels_hotel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.hotels_hotel_id_seq OWNER TO postgres;

--
-- TOC entry 5010 (class 0 OID 0)
-- Dependencies: 218
-- Name: hotels_hotel_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.hotels_hotel_id_seq OWNED BY hotel_schema.hotels.hotel_id;


--
-- TOC entry 227 (class 1259 OID 16751)
-- Name: lodgers; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.lodgers (
    lodger_id integer NOT NULL,
    full_name character varying(50),
    address text,
    phone character varying(50),
    mail character varying(50)
);


ALTER TABLE hotel_schema.lodgers OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16750)
-- Name: lodgers_lodger_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.lodgers_lodger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.lodgers_lodger_id_seq OWNER TO postgres;

--
-- TOC entry 5011 (class 0 OID 0)
-- Dependencies: 226
-- Name: lodgers_lodger_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.lodgers_lodger_id_seq OWNED BY hotel_schema.lodgers.lodger_id;


--
-- TOC entry 235 (class 1259 OID 16819)
-- Name: payments; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.payments (
    payment_id integer NOT NULL,
    booking_id integer,
    amount numeric(10,2),
    payment_date date,
    method character varying(50),
    status character varying(50)
);


ALTER TABLE hotel_schema.payments OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 16818)
-- Name: payments_payment_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.payments_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.payments_payment_id_seq OWNER TO postgres;

--
-- TOC entry 5012 (class 0 OID 0)
-- Dependencies: 234
-- Name: payments_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.payments_payment_id_seq OWNED BY hotel_schema.payments.payment_id;


--
-- TOC entry 225 (class 1259 OID 16739)
-- Name: price_history; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.price_history (
    price_id integer NOT NULL,
    type_id integer,
    date_start date,
    date_stop date,
    price_for_day numeric(10,2)
);


ALTER TABLE hotel_schema.price_history OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16738)
-- Name: price_history_price_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.price_history_price_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.price_history_price_id_seq OWNER TO postgres;

--
-- TOC entry 5013 (class 0 OID 0)
-- Dependencies: 224
-- Name: price_history_price_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.price_history_price_id_seq OWNED BY hotel_schema.price_history.price_id;


--
-- TOC entry 231 (class 1259 OID 16774)
-- Name: promotions; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.promotions (
    promo_id integer NOT NULL,
    name character varying(100),
    discount integer,
    start_date date,
    end_date date,
    hotel_id integer,
    type_id integer,
    CONSTRAINT promotions_discount_check CHECK (((discount >= 0) AND (discount <= 100)))
);


ALTER TABLE hotel_schema.promotions OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16773)
-- Name: promotions_promo_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.promotions_promo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.promotions_promo_id_seq OWNER TO postgres;

--
-- TOC entry 5014 (class 0 OID 0)
-- Dependencies: 230
-- Name: promotions_promo_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.promotions_promo_id_seq OWNED BY hotel_schema.promotions.promo_id;


--
-- TOC entry 221 (class 1259 OID 16709)
-- Name: room_types; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.room_types (
    type_id integer NOT NULL,
    type_name character varying(50),
    number_of_seats integer,
    facilities text,
    CONSTRAINT room_types_number_of_seats_check CHECK ((number_of_seats > 0))
);


ALTER TABLE hotel_schema.room_types OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16708)
-- Name: room_types_type_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.room_types_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.room_types_type_id_seq OWNER TO postgres;

--
-- TOC entry 5015 (class 0 OID 0)
-- Dependencies: 220
-- Name: room_types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.room_types_type_id_seq OWNED BY hotel_schema.room_types.type_id;


--
-- TOC entry 223 (class 1259 OID 16719)
-- Name: rooms; Type: TABLE; Schema: hotel_schema; Owner: postgres
--

CREATE TABLE hotel_schema.rooms (
    room_id integer NOT NULL,
    hotel_id integer,
    type_id integer,
    room_number integer,
    status character varying(20),
    CONSTRAINT rooms_status_check CHECK (((status)::text = ANY ((ARRAY['free'::character varying, 'occupied'::character varying, 'reserved'::character varying])::text[])))
);


ALTER TABLE hotel_schema.rooms OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16718)
-- Name: rooms_room_id_seq; Type: SEQUENCE; Schema: hotel_schema; Owner: postgres
--

CREATE SEQUENCE hotel_schema.rooms_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hotel_schema.rooms_room_id_seq OWNER TO postgres;

--
-- TOC entry 5016 (class 0 OID 0)
-- Dependencies: 222
-- Name: rooms_room_id_seq; Type: SEQUENCE OWNED BY; Schema: hotel_schema; Owner: postgres
--

ALTER SEQUENCE hotel_schema.rooms_room_id_seq OWNED BY hotel_schema.rooms.room_id;


--
-- TOC entry 4795 (class 2604 OID 16795)
-- Name: bookings booking_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings ALTER COLUMN booking_id SET DEFAULT nextval('hotel_schema.bookings_booking_id_seq'::regclass);


--
-- TOC entry 4797 (class 2604 OID 16834)
-- Name: cleaning cleaning_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.cleaning ALTER COLUMN cleaning_id SET DEFAULT nextval('hotel_schema.cleaning_cleaning_id_seq'::regclass);


--
-- TOC entry 4793 (class 2604 OID 16763)
-- Name: employees employee_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.employees ALTER COLUMN employee_id SET DEFAULT nextval('hotel_schema.employees_employee_id_seq'::regclass);


--
-- TOC entry 4788 (class 2604 OID 16703)
-- Name: hotels hotel_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.hotels ALTER COLUMN hotel_id SET DEFAULT nextval('hotel_schema.hotels_hotel_id_seq'::regclass);


--
-- TOC entry 4792 (class 2604 OID 16754)
-- Name: lodgers lodger_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.lodgers ALTER COLUMN lodger_id SET DEFAULT nextval('hotel_schema.lodgers_lodger_id_seq'::regclass);


--
-- TOC entry 4796 (class 2604 OID 16822)
-- Name: payments payment_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.payments ALTER COLUMN payment_id SET DEFAULT nextval('hotel_schema.payments_payment_id_seq'::regclass);


--
-- TOC entry 4791 (class 2604 OID 16742)
-- Name: price_history price_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.price_history ALTER COLUMN price_id SET DEFAULT nextval('hotel_schema.price_history_price_id_seq'::regclass);


--
-- TOC entry 4794 (class 2604 OID 16777)
-- Name: promotions promo_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.promotions ALTER COLUMN promo_id SET DEFAULT nextval('hotel_schema.promotions_promo_id_seq'::regclass);


--
-- TOC entry 4789 (class 2604 OID 16712)
-- Name: room_types type_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.room_types ALTER COLUMN type_id SET DEFAULT nextval('hotel_schema.room_types_type_id_seq'::regclass);


--
-- TOC entry 4790 (class 2604 OID 16722)
-- Name: rooms room_id; Type: DEFAULT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.rooms ALTER COLUMN room_id SET DEFAULT nextval('hotel_schema.rooms_room_id_seq'::regclass);


--
-- TOC entry 4997 (class 0 OID 16792)
-- Dependencies: 233
-- Data for Name: bookings; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.bookings (booking_id, room_id, employee_id, lodger_id, promo_id, check_in, check_out, status) FROM stdin;
1	1	1	1	\N	2025-03-01	2025-03-05	active
\.


--
-- TOC entry 5001 (class 0 OID 16831)
-- Dependencies: 237
-- Data for Name: cleaning; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.cleaning (cleaning_id, room_id, employee_id, cleaning_date, status) FROM stdin;
\.


--
-- TOC entry 4993 (class 0 OID 16760)
-- Dependencies: 229
-- Data for Name: employees; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.employees (employee_id, hotel_id, type_of_employment, contract_number, date_of_conclusion, end_date, terms_of_the_contract, job_title, rates) FROM stdin;
1	1	permanent	C001	2025-01-01	\N	Full	admin	1.0
\.


--
-- TOC entry 4983 (class 0 OID 16700)
-- Dependencies: 219
-- Data for Name: hotels; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.hotels (hotel_id, name, city, address, phone_number) FROM stdin;
1	HotelTest	Madrid	Street 1	+79999
\.


--
-- TOC entry 4991 (class 0 OID 16751)
-- Dependencies: 227
-- Data for Name: lodgers; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.lodgers (lodger_id, full_name, address, phone, mail) FROM stdin;
1	Ivan Ivanov	Moscow	+7999	ivan@mail.com
\.


--
-- TOC entry 4999 (class 0 OID 16819)
-- Dependencies: 235
-- Data for Name: payments; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.payments (payment_id, booking_id, amount, payment_date, method, status) FROM stdin;
\.


--
-- TOC entry 4989 (class 0 OID 16739)
-- Dependencies: 225
-- Data for Name: price_history; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.price_history (price_id, type_id, date_start, date_stop, price_for_day) FROM stdin;
\.


--
-- TOC entry 4995 (class 0 OID 16774)
-- Dependencies: 231
-- Data for Name: promotions; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.promotions (promo_id, name, discount, start_date, end_date, hotel_id, type_id) FROM stdin;
\.


--
-- TOC entry 4985 (class 0 OID 16709)
-- Dependencies: 221
-- Data for Name: room_types; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.room_types (type_id, type_name, number_of_seats, facilities) FROM stdin;
1	Single	1	WiFi
\.


--
-- TOC entry 4987 (class 0 OID 16719)
-- Dependencies: 223
-- Data for Name: rooms; Type: TABLE DATA; Schema: hotel_schema; Owner: postgres
--

COPY hotel_schema.rooms (room_id, hotel_id, type_id, room_number, status) FROM stdin;
1	1	1	101	free
\.


--
-- TOC entry 5017 (class 0 OID 0)
-- Dependencies: 232
-- Name: bookings_booking_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.bookings_booking_id_seq', 1, true);


--
-- TOC entry 5018 (class 0 OID 0)
-- Dependencies: 236
-- Name: cleaning_cleaning_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.cleaning_cleaning_id_seq', 1, false);


--
-- TOC entry 5019 (class 0 OID 0)
-- Dependencies: 228
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.employees_employee_id_seq', 1, true);


--
-- TOC entry 5020 (class 0 OID 0)
-- Dependencies: 218
-- Name: hotels_hotel_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.hotels_hotel_id_seq', 1, true);


--
-- TOC entry 5021 (class 0 OID 0)
-- Dependencies: 226
-- Name: lodgers_lodger_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.lodgers_lodger_id_seq', 1, true);


--
-- TOC entry 5022 (class 0 OID 0)
-- Dependencies: 234
-- Name: payments_payment_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.payments_payment_id_seq', 1, false);


--
-- TOC entry 5023 (class 0 OID 0)
-- Dependencies: 224
-- Name: price_history_price_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.price_history_price_id_seq', 1, false);


--
-- TOC entry 5024 (class 0 OID 0)
-- Dependencies: 230
-- Name: promotions_promo_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.promotions_promo_id_seq', 1, false);


--
-- TOC entry 5025 (class 0 OID 0)
-- Dependencies: 220
-- Name: room_types_type_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.room_types_type_id_seq', 1, true);


--
-- TOC entry 5026 (class 0 OID 0)
-- Dependencies: 222
-- Name: rooms_room_id_seq; Type: SEQUENCE SET; Schema: hotel_schema; Owner: postgres
--

SELECT pg_catalog.setval('hotel_schema.rooms_room_id_seq', 1, true);


--
-- TOC entry 4819 (class 2606 OID 16797)
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (booking_id);


--
-- TOC entry 4823 (class 2606 OID 16837)
-- Name: cleaning cleaning_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.cleaning
    ADD CONSTRAINT cleaning_pkey PRIMARY KEY (cleaning_id);


--
-- TOC entry 4815 (class 2606 OID 16767)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 4803 (class 2606 OID 16707)
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (hotel_id);


--
-- TOC entry 4813 (class 2606 OID 16758)
-- Name: lodgers lodgers_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.lodgers
    ADD CONSTRAINT lodgers_pkey PRIMARY KEY (lodger_id);


--
-- TOC entry 4821 (class 2606 OID 16824)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- TOC entry 4811 (class 2606 OID 16744)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (price_id);


--
-- TOC entry 4817 (class 2606 OID 16780)
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (promo_id);


--
-- TOC entry 4805 (class 2606 OID 16717)
-- Name: room_types room_types_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.room_types
    ADD CONSTRAINT room_types_pkey PRIMARY KEY (type_id);


--
-- TOC entry 4807 (class 2606 OID 16727)
-- Name: rooms rooms_hotel_id_room_number_key; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.rooms
    ADD CONSTRAINT rooms_hotel_id_room_number_key UNIQUE (hotel_id, room_number);


--
-- TOC entry 4809 (class 2606 OID 16725)
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (room_id);


--
-- TOC entry 4830 (class 2606 OID 16803)
-- Name: bookings bookings_employee_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings
    ADD CONSTRAINT bookings_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES hotel_schema.employees(employee_id);


--
-- TOC entry 4831 (class 2606 OID 16808)
-- Name: bookings bookings_lodger_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings
    ADD CONSTRAINT bookings_lodger_id_fkey FOREIGN KEY (lodger_id) REFERENCES hotel_schema.lodgers(lodger_id);


--
-- TOC entry 4832 (class 2606 OID 16813)
-- Name: bookings bookings_promo_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings
    ADD CONSTRAINT bookings_promo_id_fkey FOREIGN KEY (promo_id) REFERENCES hotel_schema.promotions(promo_id);


--
-- TOC entry 4833 (class 2606 OID 16798)
-- Name: bookings bookings_room_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.bookings
    ADD CONSTRAINT bookings_room_id_fkey FOREIGN KEY (room_id) REFERENCES hotel_schema.rooms(room_id);


--
-- TOC entry 4835 (class 2606 OID 16843)
-- Name: cleaning cleaning_employee_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.cleaning
    ADD CONSTRAINT cleaning_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES hotel_schema.employees(employee_id);


--
-- TOC entry 4836 (class 2606 OID 16838)
-- Name: cleaning cleaning_room_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.cleaning
    ADD CONSTRAINT cleaning_room_id_fkey FOREIGN KEY (room_id) REFERENCES hotel_schema.rooms(room_id);


--
-- TOC entry 4827 (class 2606 OID 16768)
-- Name: employees employees_hotel_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.employees
    ADD CONSTRAINT employees_hotel_id_fkey FOREIGN KEY (hotel_id) REFERENCES hotel_schema.hotels(hotel_id);


--
-- TOC entry 4834 (class 2606 OID 16825)
-- Name: payments payments_booking_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.payments
    ADD CONSTRAINT payments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES hotel_schema.bookings(booking_id);


--
-- TOC entry 4826 (class 2606 OID 16745)
-- Name: price_history price_history_type_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.price_history
    ADD CONSTRAINT price_history_type_id_fkey FOREIGN KEY (type_id) REFERENCES hotel_schema.room_types(type_id);


--
-- TOC entry 4828 (class 2606 OID 16781)
-- Name: promotions promotions_hotel_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.promotions
    ADD CONSTRAINT promotions_hotel_id_fkey FOREIGN KEY (hotel_id) REFERENCES hotel_schema.hotels(hotel_id);


--
-- TOC entry 4829 (class 2606 OID 16786)
-- Name: promotions promotions_type_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.promotions
    ADD CONSTRAINT promotions_type_id_fkey FOREIGN KEY (type_id) REFERENCES hotel_schema.room_types(type_id);


--
-- TOC entry 4824 (class 2606 OID 16728)
-- Name: rooms rooms_hotel_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.rooms
    ADD CONSTRAINT rooms_hotel_id_fkey FOREIGN KEY (hotel_id) REFERENCES hotel_schema.hotels(hotel_id);


--
-- TOC entry 4825 (class 2606 OID 16733)
-- Name: rooms rooms_type_id_fkey; Type: FK CONSTRAINT; Schema: hotel_schema; Owner: postgres
--

ALTER TABLE ONLY hotel_schema.rooms
    ADD CONSTRAINT rooms_type_id_fkey FOREIGN KEY (type_id) REFERENCES hotel_schema.room_types(type_id);


-- Completed on 2026-04-03 14:48:38

--
-- PostgreSQL database dump complete
--

\unrestrict y6znbMvkdZYccXsOOcjv0aeKzV5T9YYH3eaXWA7rXvBSdQsbsWBgo58HhWIVFTE

